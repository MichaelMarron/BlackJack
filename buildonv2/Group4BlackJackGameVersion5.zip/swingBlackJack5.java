import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class swingBlackJack5 implements ActionListener
{
int moneyBet;					//Bet amount (NOT IMPLEMENTED MONEY YET)
int numberOfCards = 2;			//Number of Cards is always 2, unless in custom game
int winningCond = 21;			//Hand Value for a win is always 21, unless in custom game

int numberOfPlayers;			//Selected Number of players (from setup)
Deck deck;						//Deck of cards (from dealInitialCards)
blackjackHand dealer;			//Dealer's Hand (from dealInitialCards)
blackjackHand[] players;		//Array containing hand objects for each player (from dealInitialCards)
String[] player_choice;  		//Array of player choices (Whether they stick or hit)
int[] finalValues;		 		//Array of the final hand values for all players
int playerCount = -1; 			//Value that acts as pointer to position in players[] when repeating game method
boolean startLogic = false;		//Switch that activates once players have finished their initial turns
boolean finish = false;			//Switch that activates when the game should end

//Comboboxes, Buttons, Labels, Text, etc...
String[] numPlayersRange = {"","1","2","3","4","5","6","7","8","9"};
JComboBox numPlayers = new JComboBox(numPlayersRange);
JLabel numPlayersLabel = new JLabel("Select Number of Players");
JButton blackjackHit = new JButton("Hit  ");
JButton blackjackStick = new JButton("Stick");
JButton blackjackDeal = new JButton("Deal ");
JTextArea ConsoleOutput = new JTextArea();
JTextArea UserInstructions = new JTextArea();
JScrollPane scrollPane = new JScrollPane(ConsoleOutput);

//Instantiate panel
JPanel p = new JPanel();

	public swingBlackJack5()
	{
		//ActionListeners
		blackjackHit.addActionListener(this);
		blackjackStick.addActionListener(this);
		blackjackDeal.addActionListener(this);
		numPlayers.addActionListener(this);

		//Add objects to frame
		p.add(scrollPane);
		p.add(UserInstructions);
		p.add(numPlayersLabel);
		p.add(numPlayers);
		p.add(blackjackDeal);
		p.add(blackjackHit);
		p.add(blackjackStick);

		//Hide Hit and Stick button untill game has begun
		blackjackHit.setVisible(false);
		blackjackStick.setVisible(false);

		//Set Size of Console Outputs
		UserInstructions.setPreferredSize(new Dimension(250,170));
		scrollPane.setPreferredSize(new Dimension(250, 170));

		//Set Console window to non-editable and set dimensions
		ConsoleOutput.setEditable(false);
		UserInstructions.setEditable(false);
	}


	//Creates blackjack panel within existing panel (WEIRD INTEGRATION CODE STUFF- NEEDS EXPLAINING)
	public void swingtime (JPanel masterPanel)
	{
			masterPanel.add(p);
			masterPanel.setVisible(true);
	}


	///Method to create players, dealer and deck
	public void setup()
	{
		//DEBUG
		System.out.println("Setup() called Successfully");

		//Creates Players and Dealer
		dealer = new blackjackHand();
		players = new blackjackHand[numberOfPlayers];

		//For number of Players, instantiate them (i.e. player[0], player[1],..)
		for (int i=0; i<numberOfPlayers; i++)
		{
			players[i] = new blackjackHand();
			String player = "Player " + (i+1) + " Created\n";
			ConsoleOutput.append(player);
		}

		//Create a new standard deck
		StandardDeck tmpdeck = new StandardDeck();
		ConsoleOutput.append("\nDeck Created...\n");

		//Shuffles Deck
		tmpdeck.shuffleCards();
	    deck = tmpdeck;
		ConsoleOutput.append("Deck Shuffled...\n");

		//Once Finished setting up game, call method to deal initial cards
        dealInitialCards();
	}


	 // Method to deal the intial cards to each player and the dealer
	 public void dealInitialCards()
	 {
		System.out.println("dealInitialCards() Called Successfully");
	 	ConsoleOutput.append("\nDealing Initial Cards...\n..............\n");

		// Give a card to each player THEN dealer, so many times
		for (int i=0; i<numberOfCards; i++)
		{
			Card card;

			//For each player in players array, give a card
			for (int x=0; x<numberOfPlayers; x++)
			{
				card = deck.getCard(0);
				players[x].addCard(card);
				deck.removeCard(0);
				ConsoleOutput.append("Player " + (x+1) + " recieves " + card.getRankString() + " of " + card.getSuitString() + "\n");
			}
			card = deck.getCard(0);
			dealer.addCard(card);
			deck.removeCard(0);
			ConsoleOutput.append("Dealer recieves " + card.getRankString() + " of " + card.getSuitString() + "\n\n");
		}

		//Instantiate Array to hold players choices (Hit or Stick)
		//Instantiate Array to hold the final hand values of each player
		player_choice = new String[numberOfPlayers];
		finalValues = new int[numberOfPlayers];

	   //Print out player and dealer results after initial deal
	   ConsoleOutput.append("\nResults after Deal:\n..................\n");

		//If the player has a winning hand: stick and print this, else just print their result
		for (int c=0; c<players.length; c++)
		{
			int playVal = players[c].evaluateHand();
			if(playVal == winningCond)
			{
				ConsoleOutput.append("Player " + (c+1) + " has a PERFECT hand of " + playVal + "\n");
				player_choice[c] = "s";
				finalValues[c] = playVal;
			}
			else
			{
				ConsoleOutput.append("Player " + (c+1) + " hand has a value of " + playVal + "\n");
			}
		}

		//Same as above for dealer
		int dealVal = dealer.evaluateHand();
		if (dealVal == winningCond)
		{
			ConsoleOutput.append("The Dealer has a perfect hand!\n...GAME OVER...\n");
			blackjackDeal.setVisible(false);
			blackjackHit.setVisible(true);
			return;
			//Probably need new method to quit game
		}
		else
		{
			ConsoleOutput.append("The Dealer's hand has a value of " + dealVal + "\n");
		}
		ConsoleOutput.append("\n");
    }


	//ActionListener Methods
	public void actionPerformed(ActionEvent e)
	{
		//Listener for deal buttons
		if (e.getSource()==blackjackDeal)
		{
			//Hide relavent buttons and call initial setup methods
			numPlayersLabel.setVisible(false);
			numPlayers.setVisible(false);
			blackjackDeal.setVisible(false);
			blackjackHit.setVisible(true);
			blackjackStick.setVisible(true);
			setup();
			initialChoice();
		}

		//Listener for comboBox that dictates number of players
		if (e.getSource() == numPlayers)
		{
			numberOfPlayers = Integer.parseInt(numPlayers.getSelectedItem().toString());
		}

		//Listener for 'Stick' button
		if (e.getSource()==blackjackStick)
		{
			//Logic for after initial dealing phase
			if (startLogic == true)
			{
				System.out.println("Player " + (playerCount+1) + " has stuck, thier turn should end");
				ConsoleOutput.append("Player " + (playerCount+1) + "Has stuck ending thier turn\n");
				player_choice[playerCount] = "s";
				finalValues[playerCount] = players[playerCount].evaluateHand();
				playerCount++;
				game();
			}

			//Logic for initial dealing phase
			if (startLogic == false)
			{
				//If all players have not selected their initial choice...
				if (Arrays.asList(player_choice).contains(null))
				{
					System.out.println("Stick");
					ConsoleOutput.append("Player " + (playerCount+1) + " Has Chosen to Stick \n");
					player_choice[playerCount] = "s";
					finalValues[playerCount] = players[playerCount].evaluateHand();

					//If all players still have not selected their initial choice, then ask again
					if (Arrays.asList(player_choice).contains(null))
					{
						initialChoice();
					}
				}

				//If all players have not selected their choice then move to game method
				if (!Arrays.asList(player_choice).contains(null))
				{
					System.out.println("Last person stuck, entering game logic stage...");
					playerCount = 0;
					game();
				}
			}
		}

		//Listener for Hit Button
		if (e.getSource()==blackjackHit)
		{
			//Logic for after initial dealing phase
			if (startLogic == true)
			{
				System.out.println("Hit");
				ConsoleOutput.append("\nPlayer " + (playerCount+1) + "Has Hit!\n");
				int hitScore = hit(playerCount);
				game();
			}

			//Logic for initial dealing phase
			if (startLogic == false)
			{
				//If all players have not selected their initial choice...
				if (Arrays.asList(player_choice).contains(null))
				{
					System.out.println("Hit");
					ConsoleOutput.append("Player " + (playerCount+1) + " Has Chosen to Hit\n");
					player_choice[playerCount] = "h";

					if (Arrays.asList(player_choice).contains(null))
					{
						initialChoice();
					}
				}

				if (!Arrays.asList(player_choice).contains(null))
				{
					System.out.println("Last person hit, entering game logic stage...");
					playerCount =0;
					game();
				}
			}
		}
	}

	// Method for logic for initial choice of players
	public void initialChoice()
	{
		if(playerCount < numberOfPlayers)
		{
			playerCount++;
			//UserInstructions.setText("Player " + (playerCount+1) + " Please Stick or Hit\n");
			UserInstructions.setText("###########\nPlayer " + (playerCount+1) + "\n###########\n Score: " + players[playerCount].evaluateHand() + "\n Please Stick or Hit");
		}

		if(playerCount >= numberOfPlayers)
		{
			//If all players have made initial choice, tell them no more players
			//DEBUG: If this appears then something has gone wrong
			UserInstructions.setText("There is no Player " + (playerCount+1) + "\n");
		}
	}


	//Game method that does game-speciffic logic, is called from various methods at different states
	public void game()
	{
		if (startLogic == false)
		{
			//RUN ONCE
			//FOR EACH PLAYER in player_choice,
			//IF choice is s then nothing, if hit then run hit
			for (int i=0; i<player_choice.length; i++)
			{
				if (player_choice[i] == "h")
				{
					int tempPlayerCount = playerCount;
					hit(i);
					playerCount = tempPlayerCount;
				}
			}
			startLogic = true;
		}


		if (playerCount >= numberOfPlayers)
		{
			results();
			playerCount--;
			finish = true;

			//As game has ended, hide buttons and display button to ask user if they would like to play again
			blackjackHit.setVisible(false);
			blackjackStick.setVisible(false);
		}


		if (finish == false)
		{
			//DEBUG: PRINT OUT FINAL VALUE (if stored) player's choice and players current score
			for (int i = 0; i<finalValues.length; i++)
			{
				System.out.print(finalValues[i] + ", ");
			}
			System.out.println();

			for (int i = 0; i<player_choice.length; i++)
			{
				System.out.print(player_choice[i] + ", ");
			}
			System.out.println();


			if (playerCount < numberOfPlayers)
			{
				if (player_choice[playerCount] =="s")
				{
					System.out.println("Accessed with playercount being " + playerCount +"\n");
					//UserInstructions.append("\nPlayer " + (playerCount+1) + " Has Stuck");
					ConsoleOutput.append("Player" + (playerCount+1) + " Has Stuck.....\n");
					playerCount++;
					game();

				}

				if (player_choice[playerCount] =="h")
				{
					UserInstructions.setText("###########\nPlayer " + (playerCount+1) + "\n###########\n Score: " + players[playerCount].evaluateHand() + "\n Please Stick or Hit");
				}
			}
		}
	}


			public int hit(int playerNum)
			{
				ConsoleOutput.append("\nPlayer " + (playerNum+1) + " Hits!");

				Card card = deck.getCard(0);
				players[playerNum].addCard(card);
				deck.removeCard(0);
				ConsoleOutput.append("\nPlayer " + (playerNum+1) + " recieves: " + card.getRankString() + " of " + card.getSuitString());

				int newPlayVal = players[playerNum].evaluateHand();
				ConsoleOutput.append("\nPlayer " + (playerNum+1) + "'s hand now has a value of " + newPlayVal + "\n");
				checkPlayerValue(playerNum, newPlayVal);
				ConsoleOutput.append("\n");
				return newPlayVal;
			}


			//CHECK IF PLAYER HAS winningCond
			public void checkPlayerValue(int playerNum, int playerVal)
			{
				if (playerVal == winningCond)
				{
					UserInstructions.append("Player " + (playerNum+1) + " Has got Blackjack! :)\n");
					ConsoleOutput.append("Player " + (playerNum+1) + " Has got Blackjack!\n");
					UserInstructions.setText("###########\nPlayer " + (playerNum+1) + "\n###########\n Score: " + playerVal);
					finalValues[playerNum] = playerVal;
					player_choice[playerNum] = "s";
					playerCount++;

				}

				if (playerVal > winningCond)
				{
					ConsoleOutput.append("Player " + (playerNum+1) + " Has Bust!\n");
					UserInstructions.setText("###########\nPlayer " + (playerNum+1) + "\n###########\n Has Bust!! :(");
					finalValues[playerNum] = playerVal;
					player_choice[playerNum] = "s";
					playerCount++;
				}
			}


			//CHECK IF DEALER GETS blackjack or busts
			public void checkDealerValue(int dealVal)
			{
				if (dealVal == winningCond)
				{
					ConsoleOutput.append("\nDealer HAS GOT blackjack, EVERYONE LOSES!");
					UserInstructions.setText("\nDealer HAS GOT blackjack, EVERYONE LOSES!");
					blackjackDeal.setVisible(false);
					blackjackHit.setVisible(true);
				}

				if (dealVal > winningCond)
				{
					ConsoleOutput.append("\nDealer Has gone bust, EVERYONE WINS!\n");
					UserInstructions.setText("\nDealer HAS GOT blackjack, EVERYONE WINS!");
					blackjackDeal.setVisible(false);
					blackjackHit.setVisible(true);
				}
			}



			public void results()
			{

				while (dealer.evaluateHand() < 16)
				{
					ConsoleOutput.append("\nDealer hits!\n");

					Card card = deck.getCard(0);
					dealer.addCard(card);
					deck.removeCard(0);
					ConsoleOutput.append("\nDealer recieves: " + card.getRankString() + " of " + card.getSuitString());

					int newDealVal = dealer.evaluateHand();
					ConsoleOutput.append("\nDealer hand now has a value of " + newDealVal);
					checkDealerValue(newDealVal);
				}

				for (int i=0; i<finalValues.length; i++)
				{
					if (finalValues[i] < dealer.evaluateHand() && dealer.evaluateHand() <=winningCond)
					{
						ConsoleOutput.append("\n\nPlayer "+ (i+1) + " LOST to the dealer\n");
						UserInstructions.append("\n\nPlayer "+ (i+1) + " LOST to the dealer\n");
					}

					if (finalValues[i] > dealer.evaluateHand() && finalValues[i] <=winningCond)
					{
						ConsoleOutput.append("\n\nPlayer " + (i+1) + " BEAT the dealer\n");
						UserInstructions.append("\n\nPlayer "+ (i+1) + " BEAT to the dealer\n");
					}

					if (finalValues[i] == dealer.evaluateHand() && dealer.evaluateHand() != winningCond)
					{
						ConsoleOutput.append("\n\nPlayer " + (i+1) + " DREW with the dealer\n");
						UserInstructions.append("\n\nPlayer "+ (i+1) + " DREW with the dealer\n");
					}
				}

			}











	public static void main(String[] args)
	{
		new swingBlackJack5();
	}

}
