

public interface Deck extends CardCollection
{

	//Shuffles order of cards in Deck
    public abstract void shuffleCards();

}